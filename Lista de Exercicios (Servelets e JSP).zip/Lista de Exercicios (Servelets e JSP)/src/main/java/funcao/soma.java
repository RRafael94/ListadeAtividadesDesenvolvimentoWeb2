package funcao;

public class soma {
	 public static int sum(int a, int b) {
	        return a + b;
	    }
}	
